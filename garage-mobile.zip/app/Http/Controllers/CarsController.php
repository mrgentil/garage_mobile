<?php

namespace App\Http\Controllers;

use App\Car;
use App\Repositories\CarsRepository;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class CarsController extends Controller
{
    /**
     * @var CarsRepository
     */
    private $CarsRepository;

    /**
     * PhoneController constructor.
     * @param CarsRepository $CarsRepository
     */
    public function __construct(CarsRepository $CarsRepository)
    {
        $this->CarsRepository = $CarsRepository;
    }

    public function index(?int $limit = 9)
    {
        $cars =  Car::query()->with(['user', 'category','type'])
        /*->where('active', 'active')*/
        ->orderBy('id', 'desc')
        ->paginate($limit);

        return view('cars.index', compact('cars'));
    }

    public function show(string $slug)
    {
        $cars = Car::query()
            ->with(['category', 'type', 'colors', 'user'])
            ->where('status', true)
            ->where('slug', $slug)
            ->firstOrFail();
        $related_cars = $this->CarsRepository->getRelatedCars($cars->id, $cars->category_id, 8);
        $next = $this->CarsRepository->getNextRecord($cars->id);
        $previous = $this->CarsRepository->getPreviousRecord($cars->id);

        return view('cars.show', compact('cars', 'related_cars', 'next', 'previous'));
    }
}
